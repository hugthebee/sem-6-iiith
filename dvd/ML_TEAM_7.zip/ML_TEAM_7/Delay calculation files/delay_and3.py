import csv
import re
import subprocess
import os
import time

def replace_parameters(netlist_file, parameters):
    with open(netlist_file, 'r') as file:
        netlist = file.readlines()
    
    #netlist_lines = netlist.readlines(
    for param_name, param_value in parameters.items():
        # print(param_name, param_value)
        if param_name == 'toxp_par':
            netlist[10] = re.sub(rf'(\btoxp\s*=\s*)[^ ]+', rf'\g<1>{param_value}', netlist[10])
            netlist[80] = re.sub(rf'(\btoxp\s*=\s*)[^ ]+', rf'\g<1>{param_value}', netlist[80])
        
        elif param_name == 'cqload':
            # for i, line in enumerate(netlist):
            #     if re.match(r'^Cout node5 0 \d+(\.\d+)?f', line):
            #         netlist[i] = re.sub(r'(?<=Cout node5 0 )\d+(\.\d+)?+', str(param_value), line)
            #         break 
            netlist[179] = re.sub(r'(?<=Cout node5 0 )\d+(\.\d+)?+', str(param_value),netlist[179])
                
        elif param_name == 'lmin':
            netlist[148] = re.sub(re.escape('lmin') + r'\s*=\s*\S+', f'{param_name}={param_value}', netlist[148])
            
        elif param_name == 'wmin':
            netlist[149] = re.sub(re.escape('wmin') + r'\s*=\s*\S+', f'{param_name}={param_value}', netlist[149])
        
        elif param_name == 'temp':
            netlist[168] = re.sub(r'^(\s*\.TEMP\s+)[-+]?\d+(\.\d+)?', f'.TEMP {param_value}', netlist[168])
            
        elif param_name == 'pvdd':
            # #netlist_lines1 = netlist.split('\n')
            # for i, line in enumerate(netlist):
            #     if re.match(r'^vdd supply 0 \d+(\.\d+)?+$', line):
            #         netlist[i] = re.sub(r'(?<=vdd supply 0 )\d+(\.\d+)?+', str(param_value), line)
            #         break  
            netlist[171] = re.sub(r'(?<=vdd supply 0 )\d+(\.\d+)?+', str(param_value), netlist[171])
            netlist[172] = re.sub(re.escape('pvdd') + r'\s*=\s*\S+', f'{param_name}={param_value}', netlist[172])
                
        elif param_name == 'toxe_n':
            line = netlist[10]
            if re.search(rf'\btoxe\s*=\s*[^ ]+', line):
                netlist[10] = re.sub(rf'(\btoxe\s*=\s*)[^ ]+', rf'\g<1>{param_value}', line)
            
        elif param_name == 'toxe_p':
            line = netlist[80]
            if re.search(rf'\btoxe\s*=\s*[^ ]+', line):
                netlist[80] = re.sub(rf'(\btoxe\s*=\s*)[^ ]+', rf'\g<1>{param_value}', line)
            
        elif param_name == 'toxm_n':
            line = netlist[10]
            if re.search(rf'\b(toxm\s*=\s*)([^ ]+)', line):
                netlist[10] = re.sub(rf'\b(toxm\s*=\s*)([^ ]+)', rf'\g<1>{param_value}', line)
            
        elif param_name == 'toxref_n':
            line = netlist[14]
            if re.search(rf'\b(toxref\s*=\s*)([^ ]+)', line):
                netlist[14] = re.sub(rf'\b(toxref\s*=\s*)([^ ]+)', rf'\g<1>{param_value}', line)
            
        elif param_name == 'toxm_p':
            line = netlist[80]
            if re.search(rf'\b(toxm\s*=\s*)([^ ]+)', line):
                netlist[80] = re.sub(rf'\b(toxm\s*=\s*)([^ ]+)', rf'\g<1>{param_value}', line)
            
        elif param_name == 'toxref_p':
            line = netlist[84]
            if re.search(rf'\b(toxref\s*=\s*)([^ ]+)', line):
                netlist[84] = re.sub(rf'\b(toxref\s*=\s*)([^ ]+)', rf'\g<1>{param_value}', line)
            
        elif param_name == 'xj_p':
            line = netlist[91]
            if re.search(rf'\bxj\s*=\s*[^ ]+', line):
                netlist[91] = re.sub(rf'(\bxj\s*=\s*)[^ ]+', rf'\g<1>{param_value}', line)
            
        elif param_name == 'xj_n':
            line = netlist[21]
            if re.search(rf'\bxj\s*=\s*[^ ]+', line):
                netlist[21] = re.sub(rf'(\bxj\s*=\s*)[^ ]+', rf'\g<1>{param_value}', line)
            
        elif param_name == 'ndep_n':
            line = netlist[22]
            if re.search(rf'\bndep\s*=\s*[^ ]+', line):
                netlist[22] = re.sub(rf'(\bndep\s*=\s*)[^ ]+', rf'\g<1>{param_value}', line)
            
        elif param_name == 'ndep_p':
            line = netlist[92]
            if re.search(rf'\bndep\s*=\s*[^ ]+', line):
                netlist[92] = re.sub(rf'(\bndep\s*=\s*)[^ ]+', rf'\g<1>{param_value}', line) 
            
    netlist = ''.join(netlist)
    with open(netlist_file, 'w') as file:
        file.write(netlist)


# def run_simulation(netlist_file):
#     subprocess.run(['ngspice', '-b', netlist_file])


csv_file = 'df_30k_22nm_HP_delay.csv'

file_path = "delay_and3.txt"

if os.path.exists(file_path):
    os.remove(file_path)

netlist_file = 'delay_and3.cir'
count=0

start_time = time.time()
with open(csv_file, 'r') as file:
    reader = csv.DictReader(file)
    # add first ten rows of reader to list x
    # parameters={'Vin':0,'temp':0,'pvdd':0,'cqload':0,'lmin':0,'toxe_n':0,'toxm_n':0,'toxref_n':0,'toxe_p':0,'toxm_p':0,'toxref_p':0,'toxp_par':0,'xj_n':0,'xj_p':0,'ndep_n':0,'ndep_p':0}
    for row in reader:
        parameters = {key.strip(): value.strip() for key, value in row.items()}
        replace_parameters(netlist_file, parameters)
        os.system('ngspice -b delay_and3.cir >> delay_and3.txt')
        print(count)
        count += 1
        # if count==10:
        #     break

end_time = time.time()
total_time = end_time - start_time
print(f"Total time taken: {total_time:.2f} seconds")


