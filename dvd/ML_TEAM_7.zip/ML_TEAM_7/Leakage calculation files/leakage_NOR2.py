# ximport subprocess
import os
import fileinput
import csv

def replace_params(params, line : str):
	"""Function to replace parameters."""
	# Process
	if ".PARAM Lmin" in line:
		print("{} = {}".format(".PARAM Lmin", params["lmin"]))
	elif ".PARAM Wmin" in line:
		print("{} = {}".format(".PARAM Wmin", params["wmin"]))
	# Supply
	elif "Vdd node1 gnd" in line:
		print("{} {}".format("Vdd node1 gnd", params["pvdd"]))
	# Input
	elif "VinA nodeA gnd" in line:
		print("{} {}".format("VinA nodeA gnd", params["Vin_A"]))
	elif "VinB nodeB gnd" in line:
		print("{} {}".format("VinB nodeB gnd", params["Vin_B"]))
	# NMOS
	elif "Altermod @nmos[toxe]" in line:
		print("  {} = {}".format("Altermod @nmos[toxe]", params["toxe_n"]))
	elif "Altermod @nmos[toxm]" in line:
		print("  {} = {}".format("Altermod @nmos[toxm]", params["toxm_n"]))
	elif "Altermod @nmos[toxref]" in line:
		print("  {} = {}".format("Altermod @nmos[toxref]", params["toxref_n"]))
	elif "Altermod @nmos[toxp]" in line:
		print("  {} = {}".format("Altermod @nmos[toxp]", params["toxp_par"]))
	elif "Altermod @nmos[ndep]" in line:
		print("  {} = {}".format("Altermod @nmos[ndep]", params["ndep_n"]))
	elif "Altermod @nmos[xj]" in line:
		print("  {} = {}".format("Altermod @nmos[xj]", params["xj_n"]))
	# PMOS
	elif "Altermod @pmos[toxe]" in line:
		print("  {} = {}".format("Altermod @pmos[toxe]", params["toxe_p"]))
	elif "Altermod @pmos[toxm]" in line:
		print("  {} = {}".format("Altermod @pmos[toxm]", params["toxm_p"]))
	elif "Altermod @pmos[toxref]" in line:
		print("  {} = {}".format("Altermod @pmos[toxref]", params["toxref_p"]))
	elif "Altermod @pmos[toxp]" in line:
		print("  {} = {}".format("Altermod @pmos[toxp]", params["toxp_par"]))
	elif "Altermod @pmos[ndep]" in line:
		print("  {} = {}".format("Altermod @pmos[ndep]", params["ndep_p"]))
	elif "Altermod @pmos[xj]" in line:
		print("  {} = {}".format("Altermod @pmos[xj]", params["xj_p"]))
	# Temperature
	elif "DC TEMP" in line:
		print("  DC TEMP {} {} {}".format(params['temp'], params['temp'], 1))
	# No change
	else:
		print(line, end='')

	return

def run_file(file: str):
	"""Function to run ngspice and return the output."""
	subprocess.run("ngspice -b {} -o nor2_leakage_output.txt".format(file))
	return

def format_output(leakage_file: str, count: int | None = None):
	"""Function to format the output"""
	out_file = "nor2_leakage_output.txt"
	value = ""

	for line in fileinput.input(out_file):
		if "(v(node1) * (abs(i(vina)) + abs(i(vinb)) + abs(i(vdd))))" in line:
		# if "(v(node1) * abs(i(vin)))" in line:
			value = line.split('=')[-1].strip()

	f_leakage = open(leakage_file, mode='a')
	# print(count, value)
	print(count, value, file=f_leakage)

	return

def append_to_csv(f_list, old_csv, new_csv):
	"""Function to append data to csv."""
	# Leakage data list
	new_column = []
	new_column.append("leakage_power")
	# Load data
	for line in fileinput.input(f_list):
		value = line.split()[-1].strip()
		new_column.append(value)
	
	# Write new column
	with open(old_csv, 'r') as f_old, open(new_csv, 'w', newline='') as f_new:
		old = csv.reader(f_old)
		new = csv.writer(f_new)
		for row in old:
			# Add new column data
			row.append(new_column[old.line_num - 1])
			# Remove cqload
			row.pop(4)
			# Write to new file
			new.writerow(row)
	
	return

def runner():
	"""Main Function."""
	# Load CSV containing params
	f_params = open("ip2_df_40k.csv")
	params_list = csv.DictReader(f_params)
	line_count = 0
	circuit_file = "NOR2.cir"
	f_temp = open("nor2_leakage_output.txt", mode='x')
	f_temp.close()

	# Iterate through params
	for params in params_list:
		# Update params in netlist
		for line in fileinput.input(circuit_file, inplace=True):
			replace_params(params, line)
		# Run simulation
		run_file(circuit_file)
		line_count += 1
		print(line_count)
		# Store output
		format_output("NOR2_leakage.txt", line_count)
		# if line_count == 5:
		# 	break

	# Update the csv
	append_to_csv("NOR2_leakage.txt", "ip2_df_40k.csv", "leakage_NOR2.csv")

	os.remove("nor2_leakage_output.txt")
	os.remove("NOR2_leakage.txt")
	f_params.close()
	return

if __name__ == "__main__":
	runner()
	# append_to_csv("NOR2_leakage.txt", "ip2_df_40k.csv", "leakage_NOR2.csv")
